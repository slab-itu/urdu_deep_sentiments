# -*- coding: utf-8 -*-

import argparse
import sys, time
from sklearn.metrics import precision_recall_curve
import chainer
import chainer.optimizers
import chainer.serializers
import chainer.functions as F
from chainer import Variable
from chainer import cuda
import matplotlib.pyplot as plt
from sklearn.metrics import precision_recall_curve
import numpy as np
from model import LetterClassifyer
from sklearn.metrics import precision_recall_fscore_support
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, classification_report, confusion_matrix
import os
from sklearn.metrics import average_precision_score
import glob
import csv
import sys
from sklearn.metrics import average_precision_score

def argument():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode')
    parser.add_argument('file')
    parser.add_argument('--embed', default=200, type=int)
    parser.add_argument('--vocab', default=3000, type=int)
    parser.add_argument('--hidden', default=1000, type=int)
    parser.add_argument('--epoch', default=10, type=int)
    parser.add_argument('--model', default="model")
    parser.add_argument('--classes', default=2, type=int)
    parser.add_argument('--use-gpu', action='store_true', default=False)
    parser.add_argument('--unchain', action='store_true', default=False)
    args = parser.parse_args()
    return args

# ファイルから1文字単位の列とラベルを取得
def letter_list(fname):
    
    with open(fname) as f:
        for l in f:
            # print("Line: ", l)
            body = l[:-1]
            val = int(l.split(',')[-1])
            # print("----------------------------")
            # print("val: ", val)
            # print("Body: ", body)
            # print("----------------------------")
            x = list(''.join(body.split()))
            x.append('</s>')
            yield x, val
def letter_list_text(t):
    x = list(''.join(t.split()))
    x.append('</s>')
    return x
# 
class Vocabulary:
    def __init__(self, fname):
        self.fname = fname
        self.l2i = {}
        self.i2l = []
        if not fname is None:
            self.load_vocab()
    def stoi(self, letter):
        if letter in self.l2i:
            return self.l2i[letter]
        return self.l2i['<unk>']
    def itos(self, id):
        if id < len(self.i2l):
            return self.i2l[id]
        return '<unk>'
            
    def append_letter(self, l):
        if l in self.l2i:
            return
        self.i2l.append(l)
        id = len(self.i2l) -1
        self.l2i[l] = id
    def load_vocab(self):
        self.append_letter('<unk>')
        self.append_letter('<s>')
        self.append_letter('</s>')
        with open(self.fname) as f:
            for line in f:
                nline = line[:-3]
                for l in nline:
                    self.append_letter(l)

    def save_vocab(self, filename):
        with open(filename, 'w') as f:
            for l in self.i2l:
                f.write(l + "\n")
    @staticmethod
    def load_from_file(filename):
        vocab = Vocabulary(None)
        with open(filename) as f:
            for l in f:
                l = l[:-1]
                vocab.append_letter(l)
        return vocab

def forward(src_batch, t, model, is_training, vocab, xp):
    batch_size = len(src_batch)
    src_len = len(src_batch[0])
    src_stoi = vocab.stoi
    x_batch = [Variable(xp.asarray([[src_stoi(x)]], dtype=xp.int32)) for x in src_batch[0]]
    y = model.forward(x_batch)
    if is_training:
        t = Variable(xp.asarray([t], dtype=xp.int32))
        # print("Y: ", y)
        #print("T: ", t)
        loss = F.softmax_cross_entropy(y, t)
        acc = F.accuracy(y, t)
        return y, acc, loss
    else:
        return y

def softmax(inputs):
    return np.exp(inputs) / float(sum(np.exp(inputs)))
        
def train(args):
    pred_label = []
    actual_label=[]
    outfile = open('finalmodel95.txt', 'a')
    if args.use_gpu:
        xp = cuda.cupy
        cuda.get_device(0).use()
    else:
        xp = np
    vocab = Vocabulary(args.file)
    m = LetterClassifyer(args.vocab, args.embed, args.hidden, args.classes)
    m.zerograds()
    if args.use_gpu:
        m.to_gpu()
    time_t = 1
    for e in range(args.epoch):
        opt = chainer.optimizers.Adam(alpha=0.1)
        opt.setup(m)
        opt.add_hook(chainer.optimizer.GradientClipping(5.0))
        print("epoch: %d" % e)
        i =0
        total_acc = 0
        e_acc = 0.0
        for x_batch, y in letter_list(args.file):
            #print("Actual Label: ", y)
            x_batch = [x_batch]
            output, acc, loss = forward(x_batch, y, m, True, vocab, xp)

            total_acc += acc
            e_acc += acc
            if i % time_t == 0:
                #if i != 0:
                    #total_acc /= time_t
                output=np.concatenate(output.data)
                print("time: %d, accuracy %f loss %f output %s" % (i, total_acc.data, loss.data, output))
                total_acc = 0
                if output[0]>output[1]:
                    pred_label.append(0)
                    predicted_label=0
                else:
                    pred_label.append(1)
                    predicted_label=1

                actual_label.append(y)

                






                output=max(output)
                print(output)
            print(" Actual Label: ", y, " Predicted Label: ", predicted_label)



            #outfile.write(accuracy)

                #probability_using_softmax=softmax(ab)
                #print(probability_using_softmax)


                #print("".join(x_batch[0]))
                #print(",".join([str(vocab.stoi(x)) for x in x_batch[0]]))
            loss.backward()
            if args.unchain:
                loss.unchain_backward()
            opt.update()
            i += 1
            sys.stdout.flush()


        matrix = confusion_matrix(actual_label, pred_label)
        e_acc = ((matrix[0][0] + matrix[1][1]) / (matrix[0][0] + matrix[1][0] + matrix[0][1] + matrix[1][1]))



        chainer.serializers.save_hdf5("finalmodel95/"+args.model + str(e)+ ".hdf5", m)
        vocab.save_vocab("finalmodel95/"+ args.model + str(e) + ".vocab")
        e_acc /= i
        
        outfile.write("total acc: %f" %  e_acc)
    outfile.close()



        #file=open("validation.txt","r")
        #string=file.read()
        #print (string)
    
       
          

def eval(args):
    if args.use_gpu:
        xp = cuda.cupy
        cuda.get_device(0).use()
    else:
        xp = np
    
    file1=open("a.txt","a")
    sys.stdout=file1
    for filename in glob.glob("finalmodel1/*.hdf5"):
        vocab_file = filename.replace('.hdf5', '.vocab')
        vocab = Vocabulary.load_from_file(vocab_file)
        m = LetterClassifyer(args.vocab, args.embed, args.hidden, args.classes)
        chainer.serializers.load_hdf5(filename,m) 
        
        if args.use_gpu:
            m.to_gpu()
        a=[]
        b=[]
      
        
        for x_batch, y in letter_list(args.file):
            output = forward(x_batch, None, m, False, vocab, xp)
            #print(output.data) 
            #print("hyp: %d" % np.argmax(output.data)) # label
            a.append(y)
            b.append(np.argmax(output.data))
        

        a1=precision_score(a, b)
        #for i in a:
        	#print(i)

        a2=recall_score(a, b)
        a3=accuracy_score(a, b)
        a4=2*(a2*a1)/(a2+a1)
        CM=confusion_matrix(a, b)
        acc = ((CM[0][0] + CM[1][1]) / (CM[0][0] + CM[0][1] + CM[1][0] + CM[1][1])) 
        #print(CM[0][0] ,CM[1][1],CM[0][1] , CM[1][0])

        #print(str(a1))
        #average_precision = average_precision_score(a, b)
        #print('Average precision-recall score: {0:0.2f}'.format(average_precision))
        #a5=precision_recall_curve(a, b)
        #print(a5)
    

        precision, recall, threshold = precision_recall_curve(a, b)
        print(precision)
        print(recall)
        print(threshold)





        # print("precision:",precision_score(a, b))
        # print("recall",recall_score(a, b))    
        # print("accuracy",accuracy_score(a, b))
        # print("accuracy",accuracy_score(a, b,normalize=False))
        

    

    
def main():
    args = argument()
    if args.mode == 'train':
        train(args)
    else:
        eval(args)

if __name__ == '__main__':
    main()
#
